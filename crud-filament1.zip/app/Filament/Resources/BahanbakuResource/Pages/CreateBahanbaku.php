<?php

namespace App\Filament\Resources\BahanbakuResource\Pages;

use App\Filament\Resources\BahanbakuResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBahanbaku extends CreateRecord
{
    protected static string $resource = BahanbakuResource::class;
}
